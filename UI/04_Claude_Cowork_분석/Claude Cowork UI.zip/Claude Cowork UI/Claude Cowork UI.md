#### 입력 전
![[Pasted image 20260203084852.png]]

#### 스킬 및 폴더 탐색 
![[Pasted image 20260203091730.png]]
#### Human-In-The-Loop
![[Pasted image 20260203091835.png]]

#### Markdown Artifacts 3-Panel
![[Pasted image 20260203091928.png]]

#### Thinking & 진행 상황 업데이트
![[Pasted image 20260203092041.png]]
#### 웹 검색 Tool call
![[Pasted image 20260203092310.png]]
#### 웹 검색 과정 Artifacts
![[스크린샷 2026-02-03 오전 9.23.42.png]]

#### PPT Artifacts 2-Panel
![[Pasted image 20260203092944.png]]
#### PPT Artifacts 3-Panel
![[Pasted image 20260203093130.png]]

#### 데이터 시각화 Artifacts 2-Panel
![[Pasted image 20260203093223.png]]
#### 데이터 시각화 Artifacts 3-Panel
![[Pasted image 20260203093159.png]]
